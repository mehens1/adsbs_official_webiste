@extends('layouts.app')

@section('content')
<main class="main">

    @include('layouts.secNav')

    <!-- <p>
        <a href="https://hefa.kdbs.ng">
            <img class="alignnone wp-image-1773"
                src="https://kdbs.ng/app/uploads/2020/05/Screen-Shot-2020-05-28-at-1.37.43-PM.png" alt="" width="271"
                height="138"
                srcset="/app/uploads/2020/05/Screen-Shot-2020-05-28-at-1.37.43-PM.png 554w, /app/uploads/2020/05/Screen-Shot-2020-05-28-at-1.37.43-PM-300x153.png 300w"
                sizes="(max-width: 271px) 100vw, 271px" />
        </a>
        <a href="https://ghs.kdbs.ng">
            <img class="alignnone  wp-image-3615" src="https://kdbs.ng/app/uploads/2022/06/ODGHS.png" alt="" width="304"
                height="111" srcset="/app/uploads/2022/06/ODGHS.png 591w, /app/uploads/2022/06/ODGHS-300x110.png 300w"
                sizes="(max-width: 304px) 100vw, 304px" />
        </a>
    </p> -->

</main>

@endsection

@section('aside')
@include('layouts.aside')
@endsection