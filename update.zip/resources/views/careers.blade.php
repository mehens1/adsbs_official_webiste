@extends('layouts.app')

@section('content')
<main class="main">

    @include('layouts.secNav')
    
</main>

@endsection

@section('aside')
@include('layouts.aside')
@endsection